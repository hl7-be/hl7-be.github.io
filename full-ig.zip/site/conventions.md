Conventions

Throughout this document, the following conventions apply:

Keywords like SHALL, SHOULD, MAY, MAY NOT... 



